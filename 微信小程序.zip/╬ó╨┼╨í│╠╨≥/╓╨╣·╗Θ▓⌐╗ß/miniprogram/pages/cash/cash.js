// pages/cash/cash.js
function initSubMenuDisplay(){
  return ['hidden','hidden'];
}
Page({
    data: {
      subMenuDisplay:initSubMenuDisplay(),
      currentTab:-1,
      weddings:[]
    },  
    onLoad:function(){
      this.loadAddress();
    },
    loadAddress: function () {
      wx.cloud.callFunction({
        name: 'getWeddings',
        success: res => {
          console.log('[云函数][getWeddings] 地址列表:', res)
          var weddings = res.result.data;
          this.setData({
            weddings: weddings
          })
        },
        fail: err => {
          console.error('[云函数][getWeddings] 调用失败', err)
        }
      })
    },
   tapMainMenu:function(e){
     console.log(e);
     var index=parseInt(e.currentTarget.dataset.index);
     console.log(index);
     var newSubMenuDisplay=initSubMenuDisplay();
     if(this.data.subMenuDisplay[index]=='hidden'){
       newSubMenuDisplay[index]='show';
       this.setData({currentTab:index});
     }
     else{
       newSubMenuDisplay[index]='hidden';
       this.setData({currentTab:-1});
     }
     this.setData({subMenuDisplay:newSubMenuDisplay});
   }
})