// pages/login/login.js
var app=getApp();
var host=app.globalData.host;
var timer;
var timeSecond=false,sendBolen=false;
Page({
  data: {
    currentTab:0,
    form_info:'',
    yzmvalue:"获取验证码",
    mobile:'',
    tiemvalue:60,
    flag:true,
    verifyCode:'',
    code:'',
    winHeight:500
  },
  onLoad:function(options) {
    this.getNewCode();
  },
  getNewCode:function(options){
    var that=this;
    wx.login({
      success: function(data){
        that.setData({
          code:data.code
        });
      },
    })
  },
  switchNav:function(e){
    var that=this;
    if(this.data.currentTab==e.target.dataset.current){
      return false;
    }else{
      that.setData({
        currentTab:e.target.dataset.current
      });
      that.setData({
        form_info:''
      });
    }
  },
  toRegister:function(e){
    wx.navigateTo({
      url:'../register/register'
    })
  },
  formSubmit:function(e){
    var that=this;
    var loginName=e.detail.value.loginName;
    var mobile=e.detail.value.mobile;
    var loginPassword=e.detail.value.loginPassword;
    var verifyCode=e.detail.value.verifyCode;
    var loginType=that.data.currentTab;
    var code=that.data.code;
    wx.request({
      url: host+'api/user/swxLogin',
      method:'GET',
      data:{
        'loginName':loginName,
        'mobile':mobile,
        'loginPassword':loginPassword,
        'verifyCode':verifyCode,
        'loginType':loginType,
        'code':code
      },
      header:{
        'Content-Type':'application/json'
      },
      success:function(res){
        console.log(res);
        var code=res.data.code;
        var msg=res.data.data;
        if(code=='0000'){
          app.globalData.userId=res.data.user.userId;
          wx.setStorageSync('userId', res.data.data.user.id);
          wx.setStorageSync('nickName', res.data.data.user.nickName);
          wx.setStorageSync('swx_session', res.data.data.swx_session);
          wx.setStorageSync('userMobile', res.data.data.user.mobile);
          wx.setStorageSync('openId',res.data.data.openId);
          wx.setStorageSync('token', res.data.data.token);
          wx.reLaunch({
            url: '../index/index',
          })
          console.log(2)
        }
        else{
          that.showTip(msg);
          return false;
        }
      }
    })
  },
  showTip:function(message){
    wx.showModal({
      title:'温馨提示',
      showCancel:false,
      content:message
    })
  },
getcode:function(e){
  var that=this;
  this.setData({
    flag:false
  });
  timer=setInterval(this.settime,1000);
  wx.request({
    url: host+'/api/user/getVerifyCode',
    method:'GET',
    data:{
      'mobile':this.data.mobile 
    },
    header:{
      'Content-Type':'application/json'
    },
    success:function(res){
      console.log(res);
      var code=res.data.code;
      var msg=res.data.data;
      if(code=='0000'){
        clearInterval(timer);
        this.setData({
          verifyCode:msg
        });
      }else{
        clearInterval('timer');
        this.setData({
          yzmvalue:'获取验证码',
          timevalue:60,
          flag:true
        });
        that.showTip(msg);
        return false
      }
    }
  })
},
getMobile:function(e){
  this.setData({
    mobile:e.detail.value
  })
},
settime:function(){
  var timevalue=this.data.timevalue;
  if(timevalue==0){
    clearInterval(timer)
    this.setData({
      yzmvalue:'重新获取',
      timevalue:60,
      flag:true
    })
    timeSecond=false;
    sendBolen=false;
    return;
  }
  timevalue--;
  timeSecond=true;
  sendBolen=true;
  this.setData({
    tiemvalue:timevalue,
    flag:false
  })
},
})