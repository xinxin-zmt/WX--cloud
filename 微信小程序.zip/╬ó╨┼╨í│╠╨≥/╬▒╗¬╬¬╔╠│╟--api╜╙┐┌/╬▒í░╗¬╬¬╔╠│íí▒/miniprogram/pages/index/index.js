// pages/index/index.js
var app=getApp();
var host=app.globalData.host;
Page({
  data: {
    indicatorDots:true,
    autoplay:true,
    interval:5000,
    duration:1000,
    imgUrls:[
      "../images/haibao/1.png",
      "../images/haibao/2.PNG",
      "../images/haibao/3.PNG"
    ],
    navs:[
      {
        "img":"../images/icon/hwzq.png",
        "name":"华为专区"
      },
      {
        "img":"../images/icon/ryzq.png",
        "name":"荣耀专区"
      },
      {
        "img":"../images/icon/lqzx.png",
        "name":"领券中心"
      },
      {
        "img":"../images/icon/axjj.png",
        "name":"安心居家"
      },
      {
        "img":"../images/icon/pt.png",
        "name":"拼团"
      }
    ],
    hotList:[],
    phoneList:[],
    pcList:[],
    host:host
  },
  onLoad: function (options) {
    var page=this;
    page.getBannerList();
    page.getGoodsList();
  },
  getBannerList:function(){
    var page=this;
    wx.request({
      url: host+'/api/banner/getBannerList?type=1',
      method:'GET',
      data:{},
      header:{
        'Content-Type':'application/json'
      },
      success:function(res){
        var code=res.data.code;
        var list=res.data.data;
        if(code=='0000'){
          var code=res.data.code;
          var list=res.data.data;
          if(code=='0000'){
            var imgUrls=new Array();
            for(var i=0;i<list.length;i++){
             imgUrls.push(list[i].url) ;
            }
            console.log(imgUrls);
            page.setData({imgUrls:imgUrls});
          }
        }
      }
    })
  },
  getGoodsList:function(){
    var page=this;
    wx.request({
      url: host+'/api/goods/getHomeGoodsList',
      method:'GET',
      data:{},
      header:{
        'Content-Type':'application/json'
      },
      success:function(res){
        console.log("wuhu~",page.data);
        var book=res.data.data;
        var phoneList=book.rmjs;
        var pcList=book.mssk;
        page.setData({hotList:phoneList.concat(pcList)});
        page.setData({phoneList:phoneList});
        page.setData({pcList:pcList});
      },
      fail:function(error){
        console.log(error);
        console.log("axiba!",page.data);
      }
    })
  },
  onShareAppMessage:function(){
    return{
      title:'华为商城',
      desc:'华为商城是华为公司旗下面向全国服务的电子商务平台官网，提供正品华为手机(华为P30系列、华为Mate20系列、华为nova系列、荣耀9X、荣耀智慧屏、荣耀20、荣耀V20等)',
      path:'../../pages/index/index'
    }
  }
})