// pages/register/register.js
var app=getApp();
var host=app.globalData.host;
Page({
  data: {},
  formSubmit:function(e){
    var that=this;
    var loginName=e.detail.value.loginName;
    var mobile=e.detail.value.mobile;
    var loginPassword=e.detail.value.loginPassword;
    var nickName=e.detail.value.nickName;
    wx.request({
      url: host+'/api/user/register',
      method:'GET',
      data:{
        'loginName':loginName,
        'mobile':mobile,
        'loginPassword':loginPassword,
        'confirmPassword':confirmPassword,
        'nickName':nickName
      },
      header:{
        'Content-Type':'application/json'
      },
      success:function(res){
        var code=res.data.code;
        var msg=rs.data.data;
        if(code=='0000'){
          wx.redirectTo({
            url: '../login/login'
          })
        }else{
          that.showTip(msg);
          return false
        }
      }
    })
  },
  showTip:function(message){
    wx.showModal({
      title:'温馨提示',
      showCancet:false,
      content:message
    })
  }
})