const express = require('express');
const app = express();
const port = 8888;

// 使用中间件解析JSON请求体
app.use(express.json());

// 模拟数据存储
let data =
{
    data: {
        rmjs: [
            { id: 1, listPic: 'https://res4.vmallres.com/pimages/uomcdn/CN/pms/202410/gbom/6942103137129/800_800_CC8A9746DF24D6EA90EF9322630569DCmp.png', goodsName: 'HUAWEI Mate 30 Pro 5G 全网通', goodsPrice: 5899 },
            { id: 2, listPic: 'https://res6.vmallres.com/pimages/uomcdn/CN/pms/202410/gbom/6942103138041/800_800_0F9C25112FD5046B6FCCDA2C45CD63AAmp.png', goodsName: '荣耀v30 双模5G 麒麟990', goodsPrice: 2999 },
            { id: 3, listPic: 'https://res2.vmallres.com/pimages/uomcdn/CN/pms/202312/gbom/6942103114014/800_800_DACD4B8DD7D6127ED11DD9CC871597A7mp.png', goodsName: 'HUAWEI Mate 30 5G 全网通', goodsPrice: 4499 }
        ]
        ,
        mssk: [
            { id: 4, listPic: 'https://res2.vmallres.com/pimages/uomcdn/CN/pms/202407/gbom/6942103122422/800_800_23F9381F2E427A33EF28B5C3533627AAmp.png', goodsName: 'HUAWEI MateBook X Pro 2019款', goodsPrice: 7799 },
            { id: 5, listPic: 'https://res5.vmallres.com/pimages/uomcdn/CN/pms/202307/gbom/6942103106590/800_800_F3ED279607CA3BCDB5569F8493263CC2mp.png', goodsName: 'HUAWEI MateBook 13 2020款', goodsPrice: 5988 },
            { id: 6, listPic: 'https://res3.vmallres.com/pimages/uomcdn/CN/pms/202403/gbom/6942103117060/800_800_B0E613B07478197CE91F1E1D61F3FCB1mp.png', goodsName: 'HUAWEI MateBook D 14', goodsPrice: 4199 }
        ]

    }
};
// 定义一个GET请求，返回所有数据
app.get('/api/goods/getHomeGoodsList', (req, res) => {
    res.json(data);
});

// 假设这是您的轮播图数据，通常您会从数据库或其他数据源获取这些数据  
const bannerData = [  
    { id: 1, url: 'https://res.vmallres.com/uomcdn/CN/cms/202411/5c9372b4cb98405fb29a2861c0221fca.jpg' },  
    { id: 2, url: 'https://res.vmallres.com/uomcdn/CN/cms/202410/3c466cc67d1049dcbf663a5bc0a51a1f.jpg' },  
    { id: 3, url: 'https://res.vmallres.com/uomcdn/CN/cms/202411/78bddc7ce1db4140bd577dae7d153ac8.jpg' }, 
  ];  
    
  // 中间件来解析JSON请求体（虽然对于GET请求这不是必需的）  
  app.use(express.json());  
    
  // 路由处理函数，用于处理/api/banner/getBannerList的GET请求  
  app.get('/api/banner/getBannerList', (req, res) => {  
    const { type } = req.query; // 从查询参数中获取type  
    
    // 根据type过滤数据（这里只是一个简单的示例，实际中可能涉及更复杂的逻辑）  
    let filteredData = bannerData;  
    if (type && type === '1') {  
      // 假设type=1表示我们想要返回所有轮播图数据  
      // 如果需要更复杂的过滤逻辑，可以在这里实现  
    } else {  
      // 如果type不匹配或未提供，可以返回一个空数组或错误消息  
      // filteredData = [];  
      // res.status(400).json({ code: '4000', message: 'Invalid type' });  
      // 在这个示例中，我们假设不提供type也返回所有数据  
    }      
    // 返回成功响应和数据  
    res.json({  
      code: '0000', // 成功状态码  
      data: filteredData, // 轮播图数据  
    });  
  });  

  const categoryData = 
  [
    { id: 0, firstid:0,firstTypeName:"新品",
        children:
        [
            {secondid:0,secondTypeIcon:"https://res.vmallres.com/uomcdn/CN/cms/202408/f3330541c48c41f5bbaf8817ef8a5b25.png.webp",secondTypeName:"HUAWEI P30"}
        ]
    },  
    { id: 1, firstid:0,firstTypeName:"华为手机",
        children:
        [
            {secondid:0,secondTypeIcon:"https://res.vmallres.com/uomcdn/CN/cms/202408/f3330541c48c41f5bbaf8817ef8a5b25.png.webp",secondTypeName:"HUAWEI P30"}
        ]
    },
    { id: 2, firstid:0,firstTypeName:"荣耀手机",
        children:
        [
            {secondid:0,secondTypeIcon:"https://res.vmallres.com/uomcdn/CN/cms/202408/f3330541c48c41f5bbaf8817ef8a5b25.png.webp",secondTypeName:"HUAWEI P30 Pro"}
        ]    
    }, 
    { id: 3, firstid:0,firstTypeName:"笔记本&平板",
        children:
        [
            {secondid:0,secondTypeIcon:"https://res.vmallres.com/uomcdn/CN/cms/202408/f3330541c48c41f5bbaf8817ef8a5b25.png.webp",secondTypeName:"HUAWEI Mate30 Pro 5G"}
        ]    
    },  
    { id: 4, firstid:0,firstTypeName:"智能穿戴&VR",
        children:
        [
            {secondid:0,secondTypeIcon:"https://res.vmallres.com/uomcdn/CN/cms/202408/f3330541c48c41f5bbaf8817ef8a5b25.png.webp",secondTypeName:"HUAWEI P30"}
        ]  
    },  
    { id: 5, firstid:0,firstTypeName:"智能家园",
        children:
        [
            {secondid:0,secondTypeIcon:"https://res.vmallres.com/uomcdn/CN/cms/202408/f3330541c48c41f5bbaf8817ef8a5b25.png.webp",secondTypeName:"HUAWEI P30"}
        ]  
    }, 
    { id: 6, firstid:0,firstTypeName:"智慧屏",
        children:
        [
            {secondid:0,secondTypeIcon:"https://res.vmallres.com/uomcdn/CN/cms/202408/f3330541c48c41f5bbaf8817ef8a5b25.png.webp",secondTypeName:"HUAWEI P30"}
        ]  
    },  
    { id: 7, firstid:0,firstTypeName:"耳机音响",
        children:
        [
            {secondid:0,secondTypeIcon:"https://res.vmallres.com/uomcdn/CN/cms/202408/f3330541c48c41f5bbaf8817ef8a5b25.png.webp",secondTypeName:"HUAWEI P30"}
        ]  
    },  
    { id: 8, firstid:0,firstTypeName:"专属配件",
        children:
        [
            {secondid:0,secondTypeIcon:"https://res.vmallres.com/uomcdn/CN/cms/202408/f3330541c48c41f5bbaf8817ef8a5b25.png.webp",secondTypeName:"HUAWEI P30"}
        ]  
    },
  ];  
    
  // 中间件来解析JSON请求体（虽然对于GET请求这不是必需的）  
  app.use(express.json());  
  // 路由处理函数，用于处理/api/banner/getBannerList的GET请求  
  app.get('/api/category/getCategoryList', (req, res) => {  
    // 根据type过滤数据（这里只是一个简单的示例，实际中可能涉及更复杂的逻辑）  
    let filteredData = categoryData;      
    // 返回成功响应和数据  
    res.json({  
      code: '0000', // 成功状态码  
      data: filteredData, // 数据  
    });  
  });  


// 定义一个POST请求，添加新数据
app.post('/api/data', (req, res) => {
    const newData = req.body;
    data.push(newData);
    res.status(201).json(newData);
});

// 启动服务器
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
