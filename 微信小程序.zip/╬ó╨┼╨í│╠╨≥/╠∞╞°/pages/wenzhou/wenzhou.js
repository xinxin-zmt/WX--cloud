Page({
  data:{
    temp:"2",
    low:"-1℃",
    high:"10℃",
    type:"晴",
    city:"温州",
    week:"星期二",
    weather:"无持续风向 微风级",
    tp1:"多云",
    tp2:"阴",
    b1:"三",
    reminder:"友情提示：天气转凉，空气湿度较大，较易发生感冒，体质较弱的朋友请注意适当防护。"
  }
  }
  )