// pages/update/update.js
Page({
  data:{
    reminder:"友情提示：天气转凉，空气湿度较大，较易发生感冒，体质较弱的朋友请注意适当防护。",
    cityId:'',
    daily:[],
    weekday:'',
    thd:[],
    wek1:'',
    wek2:'',
    wek3:''
  },
  onLoad:function(options){
    var page=this;
    if (options.id) {  
      this.setData({  
        cityId: options.id,
        cityName:options.name  
      });   
      console.log("你成功啦！",options);
      this.loadCities();
      this.load3d();
    }
  },
  loadCities:function(){
    var page=this;
    var cityId = this.data.cityId;
    wx.request({
      url: '  https://devapi.qweather.com/v7/weather/now?location=' + cityId +'&key=cf38777d27044fa897d2679323487da6',
      method:'GET',
      success: function(res) {  
        // 处理响应数据  
        console.log(res.data);  
        var daily=res.data.now;
        console.log("你又成功啦！",daily);
        page.setData({daily:daily});
        // 解析 obsTime  
        const date = new Date(daily.obsTime.replace('T', ' ').replace('+08:00', ''));  
        // 获取星期几（0-6，0代表星期日）  
        const dayOfWeek = date.getDay();  
        // 转换为中文星期几  
        const daysOfWeek = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];  
        const weekday = daysOfWeek[dayOfWeek];  
        // 输出结果  
        console.log(weekday); 
        // 根据需要更新页面数据
          page.setData({weekday:weekday});
    }
    })
  },
  load3d:function(){
    var page=this;
    var cityId = this.data.cityId;
    wx.request({
      url: '  https://devapi.qweather.com/v7/weather/3d?location=' + cityId +'&key=cf38777d27044fa897d2679323487da6',
      method:'GET',
      success: function(res) {  
        // 处理响应数据  
        console.log(res.data);  
        var thd=res.data.daily;
        console.log("你叕成功啦！",thd);
        page.setData({thd:thd});
        // 解析 fxDate--1    
        const date1 = new Date(thd[0].fxDate);  
        const xq1 = date1.toLocaleDateString('zh-CN', { weekday: 'long' });  
        console.log("输出:",xq1); // 输出：星期六
        // 根据需要更新页面数据
          page.setData({wek1:xq1});
          // 解析 fxDate--2    
        const date2 = new Date(thd[1].fxDate);  
        const xq2 = date2.toLocaleDateString('zh-CN', { weekday: 'long' });  
        console.log("输出:",xq2); // 输出：星期六
        // 根据需要更新页面数据
          page.setData({wek2:xq2});
         // 解析 fxDate--3   
        const date3 = new Date(thd[2].fxDate);  
        const xq3 = date3.toLocaleDateString('zh-CN', { weekday: 'long' });  
        console.log("输出:",xq3); // 输出：星期六
        // 根据需要更新页面数据
          page.setData({wek3:xq3});
    }
    })
  }
  })