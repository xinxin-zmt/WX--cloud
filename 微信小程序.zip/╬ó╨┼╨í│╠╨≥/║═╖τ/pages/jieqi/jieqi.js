// pages/jieqi/jieqi.js
Page({
  data: {
   
  }
})