// pages/city/city.js
Page({
  data:{
      currentTab:0,
      winWidth:0,
      winHeight:0,
      indicatorDots:true,
      autoplay:true,
      interval:5000,
      duration:1000,
      imgUrls:[
        "/image/haibao/banner1.png",
        "/image/haibao/banner2.png",
        "/image/haibao/banner3.png",
        "/image/haibao/banner4.png"
      ],
      cities:[],
      inputValue: 'beijing'
  },
  onInputChange: function (e) {
    // 监听输入框的变化，并将输入的值存储在 data 中
    this.setData({ inputValue: e.detail.value });
  },
  onLoad:function(e){
    var page=this;
    wx.getSystemInfo({
      success:function(res){
        console.log(res);
        page.setData({winWidth:res.windowWidth});
        page.setData({winHeight:res.windowHeight});
      }
    });
    this.loadCities();
    },
  switchNav:function(e){
      var id=e.currentTarget.id;
      this.setData({currentTab:id});
  },
  loadCities:function(){
    var page=this;
    var cityName = this.data.inputValue;
    wx.request({
      url: 'https://geoapi.qweather.com/v2/city/lookup?location=' + cityName +'&key=cf38777d27044fa897d2679323487da6',
      method:'GET',
      success: function(res) {
        try {
        var cities=res.data.location;
        console.log(cities);
        page.setData({cities:cities});
        var size=cities.length;
        var len=parselnt(size/3);
        console.log(len);
        page.setData({winHeight:(len+1)*230});
        } catch (error) {
          console.log("调用失败:",error);
          page.setData({ errorMessage: "调用失败，请稍后再试。" });
        }
    }
    })
  }
})