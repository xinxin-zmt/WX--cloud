const envList = [{"envId":"address22-6gm3ni8o760aac04","alias":"address22"}]
const isMac = false
module.exports = {
    envList,
    isMac
}