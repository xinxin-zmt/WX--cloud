// pages/address/address.js
var app=getApp();
Page({
  data: {
    flag:0,
    addresses:[]
  },
  onLoad: function (e) {
    this.loadAddress();
  },
  loadAddress: function () {
    wx.cloud.callFunction({
      name: 'getAddresses',
      success: res => {
        console.log('[云函数][getAddresses] 地址列表:', res)
        var addresses = res.result.data;
        this.setData({
          addresses: addresses
        })
      },
      fail: err => {
        console.error('[云函数][getAddresses] 调用失败', err)
      }
    })
  },
  addAddress:function(e){
    wx.navigateTo({
      url:'../addressAdd/addressAdd?addressid='+e.currentTarget.id
    })
  },
  editAddress:function(e){
    wx.navigateTo({
      url:'../addressAdd/addressAdd?addressid='+e.currentTarget.id
    })
    console.log("我是编辑",e.currentTarget)
  },
  deleteAddress:function(e){
    var that=this;
    wx.cloud.callFunction({
      name:'deleteAddress',
      data:{
        id:e.currentTarget.id
      },
      success:res=>{
        console.log('[云函数][deleteAddress] 地址删除返回信息:',res);
        var count=res.result.stats.removed;
        if(count==1){
          wx.showToast({
            title: '成功',
            icon:'success',
            duration:2000,
            success:function(){
              that.loadAddress();
            }
          })
        }
      },
      fail:err=>{
        console.error('[云函数][deleteAddress] 调用失败',err);
      }
    })
  },
  switchNav:function(e){
    var index=e.currentTarget.id;
    this.setData({flag:index});
  }
})