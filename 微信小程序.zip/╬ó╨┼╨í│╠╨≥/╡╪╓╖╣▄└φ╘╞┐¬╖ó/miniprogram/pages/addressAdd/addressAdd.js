// pages/addressAdd/addressAdd.js
var app=getApp();
Page({
  data: {
    index:0,
    tip:'',
    address:'',
    region:['北京市','北京市','大兴市'],
    customitem:'全部',
    addressid:'',
    sex:'',
    phone:'',
    num:'',
    userName:'',
  },
  onLoad:function(e){
    var addressid=e.addressid;
    console.log("rrr",e);
    if(addressid !=null && addressid !=''){
      this.setData({addressid:addressid});
      this.loadAddressInfo(addressid);
    }
    },
    loadAddressInfo:function(addressid){
      var that=this;
      wx.cloud.callFunction({
        name:'getAddressInfo',
        data:{
          _id:addressid
        },
        success:res=>{
          console.log('[云函数][getAddressInfo] 地址信息:',res)
          var addresses=res.result;
          that.setData({userName:addresses.data[0].personName});
          that.setData({sex:addresses.data[0].gender});
          that.setData({phone:addresses.data[0].contactNumber});
          that.setData({num:addresses.data[0].houseNumber});
          that.setData({address:addresses.data[0].address});
          that.setData({addressid:addresses.data[0]._id});
          var cities=addresses.data[0].city;
          var region=cities.split(',');
          that.setData({region:region});
        },
        fail:err=>{
          console.error('[云函数][getAddressInfo] 调用失败',err);
        }
      })
    },
    bindPickerChange:function(e){
      this.setData({
        index:e.detail.value
      });
    },
    formSubmit:function(e){
      var citys=e.detail.value.city;
      var that=this;
      var personName=e.detail.value.userName;
      var gender=e.detail.value.sex;
      var contactNumber=e.detail.value.phone;
      var address=e.detail.value.address;
      var houseNumber=e.detail.value.num;
      var citys=e.detail.value.city;
    
      var city=citys[0];
      if(city[1]!='全部'){
        city +=','+citys[1];
      }
      if(city[2]!='全部'){
        city +=','+citys[2];
      }
      var addressid=this.data.addressid;
      console.log("wsss",addressid);
      if(addressid == null || addressid == ''){
        that.addressAdd(personName,gender,contactNumber,address,houseNumber,city);
      }else{
        that.addressEdit(personName,gender,contactNumber,address,houseNumber,city,addressid);
      }
    },
    addressEdit:function(personName,gender,contactNumber,address,houseNumber,city,addressid){
      wx.cloud.callFunction({
        name:'addressEdit',
        data:{
          _id:addressid,
          personName:personName,
          gender:gender,
          contactNumber:contactNumber,
          address:address,
          houseNumber:houseNumber,
          city:city
        },
        success:res=>{
          console.log('[云函数][addressEdit] 地址修改返回信息',res);
          var errMsg=res.result.errMsg;
          if(errMsg=="document.update:ok"){
            wx.showToast({
              title: '成功',
              icon:'success',
              duration:2000,
              success:function(){
                wx.reLaunch({
                  url: '../address/address',
                })
              }
            })
          }
        },
        fail:err=>{
          console.error('[云函数][addressEdit] 调用失败',err);
        }
      })
    },
    addressAdd:function(personName,gender,contactNumber,address,houseNumber,city){
      wx.cloud.callFunction({
        name:'addressAdd',
        data:{
          personName:personName,
          gender:gender,
          contactNumber:contactNumber,
          address:address,
          houseNumber:houseNumber,
          city:city
        },
        success:res=>{
          console.log('[云函数][addressAdd] 地址添加返回信息',res);
          var errMsg=res.result.errMsg;
          if(errMsg=="collection.add:ok"){
            wx.showToast({
              title: '成功',
              icon:'success',
              duration:2000,
              success:function(){
                wx.reLaunch({
                  url: '../address/address',
                })
              }
            })
          }
        },
        fail:err=>{
          console.error('[云函数][addressAdd] 调用失败',err);
        }
      })
    },
    chooseLocation:function(){
      var page=this;
      wx.chooseLocation({
        type:'gcj02',
        success:function(res){
          var address=res.name;
          var lat=res.latitude;
          var lon=res.longitude;
          page.setData({
            address:address
          })
        }
      })
    },
    bindRegionChange:function(e){
      console.log('picker 发送选择改变，携带值为',e.detail.value);
      this.setData({
        region:e.detail.value
      })
    }
  })