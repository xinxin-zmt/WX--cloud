Page({
  data: {
    productList: [],
    orderID: '',
    orderName: '',
    editInfo: {}, // 用于存储编辑状态和值
  },
  onLoad: function() {
    this.onSearch();
  },
  onSearch: function() {
    const { orderID, orderName } = this.data;
    let url = 'http://localhost:3000/data';
    let method = 'GET';
    let data = null;
  
    if (orderID) {
      url = `http://localhost:3000/product/${orderID}`; // 使用商品 ID 进行查询
    } else if (orderName) {
      url = `http://localhost:3000/products/${orderName}`; // 使用商品名称进行模糊查询
    }
  
    wx.request({
      url: url,
      method: method,
      data: data,
      success: (res) => {
        console.log(res); // 打印响应数据
        if (res.data && res.data.length > 0) {
          this.setData({
            productList: res.data,
            editInfo: {}, // 清空编辑状态
          });
        } else {
          wx.showToast({
            title: '未找到相关商品',
            icon: 'none'
          });
        }
      },
      fail: (err) => {
        console.error(err);
        wx.showToast({
          title: '查询失败，请重试',
          icon: 'none'
        });
      }
    });
  },
  bindOrderIDInput: function(e) {
    this.setData({
      orderID: e.detail.value
    });
  },
  bindOrderNameInput: function(e) {
    this.setData({
      orderName: e.detail.value
    });
  },
  onCellTap: function(e) {
    const idx = e.currentTarget.dataset.idx;
    const field = e.currentTarget.dataset.field;
    const now = new Date().getTime();
    const lastTapTime = this.data.lastTapTime || 0;
    const doubleClick = now - lastTapTime < 300;
  
    this.setData({
      lastTapTime: now,
    });
  
    if (doubleClick) {
      this.setData({
        [`editInfo.${idx}.${field}`]: this.data.productList[idx][field], // 设置编辑状态和值
      });
    }
  },
  onEditorChange: function(e) {
    const idx = e.currentTarget.dataset.idx;
    const field = e.currentTarget.dataset.field;
    const value = e.detail.value;
    this.setData({
      [`editInfo.${idx}.${field}`]: value, // 更新编辑中的值
    });
  },
  onEditorBlur: function(e) {
    const idx = e.currentTarget.dataset.idx;
    const field = e.currentTarget.dataset.field;
    const value = this.data[`editInfo.${idx}.${field}`];
    const productList = this.data.productList;
    productList[idx][field] = value; // 更新数据
    this.setData({
      productList, // 更新商品列表
    });
  },
// 在 Page 中添加或修改 onUpdate 函数
onUpdate: function() {
  // 构建一个数组，包含所有编辑过的商品数据
  const updatedProducts = this.data.productList.map((item, idx) => {
    return {
      ProductId: item.ProductId,
      Name: this.data.editInfo[idx]?.Name || item.Name,
      Type: this.data.editInfo[idx]?.Type || item.Type,
      Des: this.data.editInfo[idx]?.Des || item.Des,
      SaleNum: this.data.editInfo[idx]?.SaleNum || item.SaleNum,
      Price: this.data.editInfo[idx]?.Price || item.Price,
      ImageURL: this.data.editInfo[idx]?.ImageURL || item.ImageURL
    };
  });

  // 发送请求到后端 API
  wx.request({
    url: 'http://localhost:3000/updateProduct', // 更新商品信息的API
    method: 'POST',
    data: updatedProducts,
    success: (res) => {
      if (res.data && res.data.status === 'success') {
        wx.showToast({
          title: '修改成功！',
          icon: 'success'
        });
        this.onSearch(); // 重新加载商品列表
      } else {
        wx.showToast({
          title: '修改失败，请重试',
          icon: 'none'
        });
      }
    },
    fail: (err) => {
      console.error(err);
      wx.showToast({
        title: '网络错误，请检查您的连接',
        icon: 'none'
      });
    }
  });
},
});