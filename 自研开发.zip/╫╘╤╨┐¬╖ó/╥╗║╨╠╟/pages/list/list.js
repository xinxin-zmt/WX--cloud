Page({
  data: {
    listData: [], // 从服务器获取的数据列表
    uniqueTypes: [], // 存储唯一的类型
    currentType: '', // 当前选中的类型
    filteredData: [], // 根据当前选中的类型过滤后的商品数据
    cartList:[],
    sumMoney:0,
    total:'',
    cartItemCount: 0
  },
  //连接api,加载数据
  onLoad: function(options) {
    wx.showLoading({ title: '努力加载中' });
    wx.request({
      url: 'http://localhost:3000/data', // 替换为你的API地址
      method: 'GET',
      success: (res) => {
        wx.hideLoading();
        if (res.statusCode === 200) {
          this.setData({ listData: res.data });
          this.extractUniqueTypes(); // 提取唯一的类型
          this.setData({ filteredData: res.data });// 默认显示所有数据
        } else {
          wx.showToast({
            title: '加载失败',
            icon: 'none'
          });
        }
      },
      fail: () => {
        wx.hideLoading();
        wx.showToast({
          title: '请求失败',
          icon: 'none'
        });
      }
    });
  },
  //类型去重显示提取
  extractUniqueTypes: function() {
    const uniqueTypes = [];
    this.data.listData.forEach(item => {
      if (!uniqueTypes.includes(item.Type)) {
        uniqueTypes.push(item.Type);
      }
    });
    console.log(uniqueTypes);
    this.setData({ uniqueTypes }); // 更新左侧菜单的数据源
  },
  //右侧菜单设置商品陈列
  selectMenu: function(e) {
    const type = e.currentTarget.dataset.type;
    this.setData({ currentType: type }); // 设置当前选中的类型
    const filtered = this.data.listData.filter(item => item.Type === type);
    this.setData({ filteredData: filtered }); // 根据选中的类型过滤商品数据
  },
  addToCart: function (e) {
    // 获取当前点击的商品所在的类型
    const currentType = this.data.currentType;
    // 从当前类型对应的已过滤数据中查找商品
    const index = e.currentTarget.dataset.index;
    const filteredData = this.data.filteredData;
    const item = filteredData[index];
    if (item && item.Name) {
      const cartItem = this.data.cartList.find(x => x.Name === item.Name);
      if (cartItem) {
        cartItem.quantity += 1;
      } else {
        this.data.cartList.push({...item, quantity: 1 });
      }
    }
    this.updateCart();
    this.setData({
      cartList: this.data.cartList,
      sumMoney: this.data.sumMoney
    });
  },
  //显示购物车列表
showCartList: function() {
    this.setData({ showCart: !this.data.showCart });
  },
// 更新购物车总金额
updateCart: function() {
    // 更新全局数据
    const app = getApp();
  const cartList = this.data.cartList;
  let sumMoney = cartList.reduce((acc, item) => {
      const price = item.Price;
      const quantity = item.quantity;
      return acc + (price * quantity);
  }, 0);
  console.log('原始总价：', sumMoney);
  app.globalData.originalTotalPrice = parseFloat(sumMoney);
  // 满减逻辑
  if (sumMoney >= 138) {
      sumMoney -= 22;
      console.log('满足 138 减 22，总价变为：', sumMoney);
  } else if (sumMoney >= 88) {
      sumMoney -= 15;
      console.log('满足 88 减 15，总价变为：', sumMoney);
  } else if (sumMoney >= 50) {
      sumMoney -= 8;
      console.log('满足 50 减 8，总价变为：', sumMoney);
  }
  sumMoney = sumMoney.toFixed(2);
  console.log('最终总价：', sumMoney);
  app.globalData.finalTotalPrice = parseFloat(sumMoney);
  this.setData({
      sumMoney: sumMoney,
      cartList: cartList
  });
},
// 增加商品数量
addNumber: function(e) {
  const index = e.currentTarget.dataset.index; // 获取购物车中商品的索引
  if (index !== undefined && index !== null) {
    const item = this.data.cartList[index];
    if (item) {
      item.quantity += 1; // 增加数量
      this.updateCart(); // 更新购物车总金额
    }
  }
},

// 减少商品数量
decNumber: function(e) {
  const index = e.currentTarget.dataset.index; // 获取购物车中商品的索引
  if (index !== undefined && index !== null) {
    const item = this.data.cartList[index];
    if (item) {
      if (item.quantity > 1) {
        item.quantity -= 1; // 减少数量
      } else {
        // 如果数量为1，则从购物车中移除
        const newList = this.data.cartList.filter((x => x !== item));
        this.setData({ cartList: newList });
      }
      this.updateCart(); // 更新购物车总金额
    }
  }
},
  //清空购物车
  clearCartList: function() {
    this.setData({
      cartList: [],
      showCart: true,
      sumMoney: 0,
      cupNumber: 0
    });
  },
  // 单击"选好了"，判断页面是否跳转
  goBalance: function() {
    console.log('sumMoney:', this.data.sumMoney);
    if (this.data.sumMoney >= 20) {
      console.log('Trying to navigate to bills page');
      const cartListString = JSON.stringify(this.data.cartList);
      console.log("Before sending data:", cartListString);
      wx.setStorageSync('cartList', cartListString);
      // 使用navigateTo跳转并传递购物车数据
      wx.navigateTo({
          url: `/pages/pay/pay?cartList=${cartListString}`,
      });
    } else {
      wx.showToast({
        title: '购物车金额不足20元',
        icon: 'none'
      });
    }
  },               
})