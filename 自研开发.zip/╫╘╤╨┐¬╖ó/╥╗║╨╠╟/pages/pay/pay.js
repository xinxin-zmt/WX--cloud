// pages/pay/pay.js
// 在Page外定义一个变量来存储备注信息
let remark = '';
Page({
  data: {
    deliveryTimes: [],
    selectedTime: null,
    address: '',
    latitude: 0,
    longitude: 0,
    selectedTag: null,
    selectedTagText: null, // 新增变量用于存储选中的tag文本
    cartList: [],
    originalTotalPrice: 0,
    finalTotalPrice: 0,
    isAlipaySelected: false,
    isWechatpaySelected: false,
    showDeliveryTimeModal: false,
    deliveryTimes: [],
    selectedTime: null,
    selectedDeliveryTimeText: "选择送达时间",
    showRemarkModal: false,
    inputLength: 0 ,// 新增用于存储输入字数的变量
    deliveryRemark: '请输入备注信息', // 新增用于存储备注信息的变量
    showTablewareModal: false,
    selectedTableware: '无需餐具',
    formData: {
      housenumber: '',
      linkphone: '',
      personname: ''
    },
  },
  submitOrder: function () {
    if (this.data.isAlipaySelected || this.data.isWechatpaySelected) {
      let now = new Date();
let year = now.getFullYear();
let month = now.getMonth() + 1;
let day = now.getDate();
let hours = now.getHours();
let minutes = now.getMinutes();
let seconds = now.getSeconds();
let formattedDateTime = `${year}-${month < 10 ? '0' + month : month}-${day < 10 ? '0' + day : day} ${hours < 10 ? '0' + hours : hours}:${minutes < 10 ? '0' + minutes : minutes}:${seconds < 10 ? '0' + seconds : seconds}`;

      const {formData} = this.data;
      console.log('formData:', formData);
      // 在函数内部声明变量
      let selectedDeliveryTimeText=this.data.selectedDeliveryTimeText;
      let discountprice=this.data.originalTotalPrice-this.data.finalTotalPrice; 
      let finalTotalPrice=this.data.finalTotalPrice;
      let deliveryRemark=this.data.deliveryRemark; 
      let selectedTableware=this.data.selectedTableware;   
      const cartList=this.data.cartList;

      // 调用函数生成随机订单编号
      const orderNum = this.generateRandom11DigitNumber();

      const dataToSend = {
        consumerData: {
          Address: this.data.address,
          HouseNumber: formData.housenumber,
          LinkPhone: formData.linkphone,
          PersonName: formData.personname,
          selectedTagText: this.data.selectedTagText
        },
        orderData:{
          OrderNum:orderNum,
          OrderTime:formattedDateTime,
          DeliveryTime:selectedDeliveryTimeText,
          DiscountPrice:discountprice,
          ConsumeMoney:finalTotalPrice,
          Remark:deliveryRemark,
          TableWare:selectedTableware,
          ConsumerPhone:formData.linkphone
        },
        productData: this.data.cartList.map(item => ({
          ProductId: item.ProductId,
          SweetName: item.Name,
          SweetPerPrice: item.Price,
          SweetNum: item.quantity,
          OrderTime: formattedDateTime,
          ConsumerPhone: formData.linkphone
        })),
      };
      console.log(cartList);
      console.log("consumerData:",dataToSend.consumerData);
      console.log("orderData:",dataToSend.orderData); 
      console.log("productData:",dataToSend.productData); 
      // 发送HTTP请求到后端API
      wx.request({
        url: 'http://localhost:3000/submitOrder', // 根据实际情况修改后端API地址
        method: 'POST',
        header: {
          'content-Type': 'application/json' // 设置 Content-Type 为 application/json
        },
        data: JSON.stringify(dataToSend), // 将 JavaScript 对象转换为 JSON 字符串
        success: (res) => {
          console.log('订单提交成功', res.data);
          // 显示成功提示
          wx.showToast({
            title: '提交成功',
            icon: 'success',
            duration: 2000
          });
        },
        fail: (err) => {
          console.error('订单提交失败', err);
          // 显示失败提示
          wx.showToast({
            title: '提交失败',
            icon: 'error',
            duration: 2000
          });
        }
      });
    } else {
      wx.showToast({
        title: '请选择支付方式',
        icon: 'loading',
        duration: 1000
      });
    }
  },
// 生成订单编号的函数
generateRandom11DigitNumber: function () {
  const now = new Date();

    // 获取年、月、日、时、分、秒，并格式化为固定长度的字符串
    const year = now.getFullYear().toString().padStart(4, '0');
    const month = (now.getMonth() + 1).toString().padStart(2, '0');
    const day = now.getDate().toString().padStart(2, '0');
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');

    // 生成四位随机数
    const randomPart = Math.floor(Math.random() * 10000).toString().padStart(4, '0');

    // 拼接成18位编号
    return year + month + day + hours + minutes + seconds + randomPart;
},
  handleInput: function(e) {
    const name = e.currentTarget.id;
    const value = e.detail.value;  
    this.setData({
      [`formData.${name}`]: value
    });
    console.log('Updated formData:', this.data.formData); // 打印更新后的数据
    console.log('address:', this.data.address); // 打印地址数据
  },
  selectTag: function(e) {
    console.log(e.currentTarget.dataset.tag);
    console.log(e._relatedInfo.anchorTargetText);
    this.setData({
      selectedTag: e.currentTarget.dataset.tag,
      selectedTagText: e._relatedInfo.anchorTargetText // 记录选中的tag文本
    });
  },
  onLoad(options) {
    this.generateDeliveryTimes();
    // 其他原有代码保持不变
    this.setData({
      isShowModal: false
    });
    const app = getApp();
    const originalTotalPrice = app.globalData.originalTotalPrice;
    const finalTotalPrice = app.globalData.finalTotalPrice;
    this.setData({
      originalTotalPrice: originalTotalPrice,
      finalTotalPrice: finalTotalPrice
    });

    const cartListString = options.cartList;
    try {
      const cartListString = wx.getStorageSync('cartList');
      const cartList = JSON.parse(cartListString);
      console.log("After receiving data:", cartListString);
      this.setData({ cartList: cartList });
    } catch (error) {
      console.error("JSON解析错误:", error);
    }
  },
  onPaymentChange: function(e) {
  const payment = e.detail.value;
  if (payment === 'alipay') {
    this.setData({
      isAlipaySelected: true,
      isWechatpaySelected: false
    });
  } else if (payment === 'wechatpay') {
    this.setData({
      isAlipaySelected: false,
      isWechatpaySelected: true
    });
  }
  console.log('Selected payment method:', payment);
},
  chooseLocation: function() {
  wx.chooseLocation({
    success: function(res) {
      const latitude = res.latitude;
      const longitude = res.longitude;
      const name = res.name;
      const address = res.address;
      // 更新页面数据中的地址
      this.setData({
        address: address,
        chosenAddress: address // 更新 chosenAddress 变量
      });
      console.log(`Name: ${name}, Address: ${address}, Latitude: ${latitude}, Longitude: ${longitude}`);
    }.bind(this),
    fail: function(err) {
      // 处理错误情况
      console.error('Failed to choose location:', err);
    }
  });
},
  generateDeliveryTimes: function() {
    const endTimeToday = 24 * 60; // 当天结束时间，24:00 转换为分钟
    let deliveryTimes = [];
    const currentTime = new Date();
    const currentHour = currentTime.getHours();
    const currentMinute = currentTime.getMinutes();
    const currentTotalMinutes = currentHour * 60 + currentMinute; // 当前总分钟数
    // 添加“立即送达”选项，显示为当前时间加一个小时
    deliveryTimes.push(`立即送达 | ${currentHour}:${currentMinute < 10 ? '0' + currentMinute : currentMinute}`);
    // 从当前时间的下一个小时开始，以30分钟为间隔生成送达时间
    for (let i = currentTotalMinutes + 30; i < endTimeToday; i += 30) {
      const startHour = Math.floor(i / 60).toString().padStart(2, '0');
      const startMinute = (i % 60).toString().padStart(2, '0');
      const endHour = Math.floor((i + 30) / 60).toString().padStart(2, '0');
      const endMinute = ((i + 30) % 60).toString().padStart(2, '0');
      const timeStr = `${startHour}:${startMinute}-${endHour}:${endMinute}`;
      deliveryTimes.push(timeStr);
    }
    this.setData({ deliveryTimes: deliveryTimes });
  },
  selectDeliveryTime: function(e) {
    const selectedTime = e.currentTarget.dataset.time;
    console.log(selectedTime);
    this.setData({
      selectedDeliveryTimeText: selectedTime, // 更新显示文本
      showDeliveryTimeModal: false // 关闭弹窗
    });
  },
  showDeliveryTimeModal: function() {
    this.setData({
      showDeliveryTimeModal: true
    });
  },
  closeDeliveryTimeModal: function() {
    this.setData({
      showDeliveryTimeModal: false
    });
  },
  showRemarkModal: function() {
    this.setData({
      showRemarkModal: true
    });
  },
  // 添加一个函数用于处理备注输入框的确定按钮点击事件
  confirmRemark: function() {
    this.setData({
      deliveryRemark:remark, // 存储备注信息
      showRemarkModal: false
    });
  },
  // 添加一个函数用于处理备注输入框的输入事件
  handleRemarkInput: function(e) {
    console.log('输入的值:', e.detail.value);
    console.log('输入的长度:', e.detail.value.length);
    remark = e.detail.value;
    inputLength= e.detail.value.length // 新增计算输入字数并存储
    this.setData({
      remark:remark,
      inputLength:e.detail.value.length
    });
  },
  toggleTablewareModal: function() {
  this.setData({
    showTablewareModal: !this.data.showTablewareModal // 切换弹窗显示状态
  });
},
  onTablewareChange: function(e) {
  this.setData({
    selectedTableware: e.detail.value
  });
},
})